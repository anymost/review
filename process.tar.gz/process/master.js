/**
 * Created by lenovo on 2017/5/27.
 */
let childProcess = require('child_process');
for(let i=0;i<5;i++){
    childProcess.execFile('./worker.js', (err, stdout, stderr)=>{

    });
}
